gsap.from(".what-makes-circle", {
    scrollTrigger: {
        trigger : '#what-make-us',
        scrub : 0.4,
        end : '+=500'
    },
    top : '200%',
  })

  gsap.from(".image-col", {
    scrollTrigger: {
        trigger : '#what-make-us',
        scrub : 0.4,
        end : '+=500'
    },
    marginTop : '50%',
  })

  

  



